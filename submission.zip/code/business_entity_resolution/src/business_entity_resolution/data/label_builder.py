"""Ground-truth label assignment and training dataset serialization."""

import os
from typing import Dict, List, Optional, Set, Tuple
import numpy as np
import pandas as pd
from pydantic import BaseModel

from ..features.feature_builder import FeatureBuilder
from ..utils.logger import setup_logger

logger = setup_logger("data.label_builder")


class LabelValidationReport(BaseModel):
    """Validation report checking integrity of generated pairwise labels."""
    is_valid: bool
    total_pairs: int
    positive_labels: int
    negative_labels: int
    positive_ratio: float
    singleton_pairs_count: int
    singleton_positive_count: int  # Must strictly be 0
    errors: List[str]


class LabelBuilder:
    """Assigns ground-truth labels to candidate pairs and constructs training datasets."""

    @staticmethod
    def build_labels_for_candidates(
        candidate_map: Dict[str, List[str]],
        ground_truth_map: Dict[str, Set[str]],
    ) -> Tuple[List[int], List[Tuple[str, str]]]:
        """Maps candidate pairs to binary labels (1 = true match, 0 = non-match).

        Rules:
        - If target_id is in ground_truth_map[s1_id], label = 1.
        - Otherwise, label = 0.
        - Source 1 entities with no matches (singletons) have ground_truth_map[s1_id] == set(),
          so all their candidate pairs strictly receive label = 0.
        - Multiple true matches for a single S1 entity are all independently labeled 1.
        - Never creates artificial positive labels.

        Args:
            candidate_map: Mapping of s1_id -> list of candidate target_ids.
            ground_truth_map: Mapping of s1_id -> set of true matching target_ids from train_ground_truth.tsv.

        Returns:
            Tuple of (labels: List[int], pairs: List[Tuple[str, str]]).
        """
        labels: List[int] = []
        pairs: List[Tuple[str, str]] = []

        for s1_id, candidate_ids in candidate_map.items():
            true_matches = ground_truth_map.get(s1_id, set())

            for target_id in candidate_ids:
                is_match = 1 if target_id in true_matches else 0
                labels.append(is_match)
                pairs.append((s1_id, target_id))

        return labels, pairs

    @staticmethod
    def validate_labels(
        pairs: List[Tuple[str, str]],
        labels: List[int],
        ground_truth_map: Dict[str, Set[str]],
    ) -> LabelValidationReport:
        """Runs strict integrity checks on assigned labels.

        Validates:
        1. Array lengths match.
        2. Labels are strictly binary (0 or 1).
        3. Every pair with label == 1 is verifiable in train_ground_truth.tsv.
        4. Every pair with label == 0 is NOT in train_ground_truth.tsv.
        5. Source 1 entities with 0 matches (singletons) have 0 positive labels.
        """
        errors: List[str] = []
        if len(pairs) != len(labels):
            errors.append(f"Length mismatch: {len(pairs)} pairs vs {len(labels)} labels.")
            return LabelValidationReport(
                is_valid=False,
                total_pairs=len(pairs),
                positive_labels=0,
                negative_labels=0,
                positive_ratio=0.0,
                singleton_pairs_count=0,
                singleton_positive_count=0,
                errors=errors,
            )

        pos_count = 0
        neg_count = 0
        singleton_pairs = 0
        singleton_pos = 0

        for (s1_id, target_id), label in zip(pairs, labels):
            if label not in (0, 1):
                errors.append(f"Invalid label value {label} for pair ({s1_id}, {target_id}).")
                continue

            true_targets = ground_truth_map.get(s1_id, set())
            is_singleton = len(true_targets) == 0

            if is_singleton:
                singleton_pairs += 1
                if label == 1:
                    singleton_pos += 1
                    errors.append(
                        f"CRITICAL: Singleton {s1_id} was assigned positive label for candidate {target_id}!"
                    )

            if label == 1:
                pos_count += 1
                if target_id not in true_targets:
                    errors.append(
                        f"False positive label error: pair ({s1_id}, {target_id}) labeled 1 but not in ground truth."
                    )
            else:
                neg_count += 1
                if target_id in true_targets:
                    errors.append(
                        f"False negative label error: pair ({s1_id}, {target_id}) labeled 0 but IS in ground truth."
                    )

        total = len(labels)
        pos_ratio = (pos_count / total) if total > 0 else 0.0
        is_valid = len(errors) == 0

        logger.info(
            f"Label validation {'PASSED' if is_valid else 'FAILED'}: "
            f"Total pairs={total:,}, Positive={pos_count:,} ({pos_ratio:.2%}), "
            f"Negative={neg_count:,}, Singleton pairs={singleton_pairs:,} (violations={singleton_pos})"
        )

        return LabelValidationReport(
            is_valid=is_valid,
            total_pairs=total,
            positive_labels=pos_count,
            negative_labels=neg_count,
            positive_ratio=round(pos_ratio, 5),
            singleton_pairs_count=singleton_pairs,
            singleton_positive_count=singleton_pos,
            errors=errors[:10],  # Keep top errors to avoid giant report
        )

    @classmethod
    def build_training_dataset(
        cls,
        candidate_map: Dict[str, List[str]],
        ground_truth_map: Dict[str, Set[str]],
        s1_lookup: Dict[str, Dict[str, str]],
        target_lookup: Dict[str, Dict[str, str]],
        feature_builder: FeatureBuilder,
    ) -> Tuple[np.ndarray, np.ndarray, List[Tuple[str, str]], LabelValidationReport]:
        """Builds feature matrix X and label vector y for candidate pairs.

        Args:
            candidate_map: Mapping of s1_id -> candidate target_ids.
            ground_truth_map: Mapping of s1_id -> set of true target IDs.
            s1_lookup: Lookup dict of S1 records.
            target_lookup: Lookup dict of target records.
            feature_builder: Configured FeatureBuilder instance.

        Returns:
            Tuple of (X: np.ndarray, y: np.ndarray, pairs: List[Tuple[str, str]], report: LabelValidationReport).
        """
        logger.info("Building ground-truth labels for candidate pairs...")
        raw_labels, raw_pairs = cls.build_labels_for_candidates(candidate_map, ground_truth_map)

        report = cls.validate_labels(raw_pairs, raw_labels, ground_truth_map)
        if not report.is_valid:
            raise ValueError(f"Label generation validation failed: {report.errors}")

        logger.info("Extracting pairwise feature matrix for candidates...")
        X, valid_pairs = feature_builder.build_feature_matrix(raw_pairs, s1_lookup, target_lookup)

        # Re-align labels if any candidate was missing from lookup
        if len(valid_pairs) != len(raw_pairs):
            pair_to_label = dict(zip(raw_pairs, raw_labels))
            y = np.array([pair_to_label[p] for p in valid_pairs], dtype=np.int32)
        else:
            y = np.array(raw_labels, dtype=np.int32)

        logger.info(f"Generated training dataset: X shape = {X.shape}, y shape = {y.shape}")
        return X, y, valid_pairs, report

    @staticmethod
    def save_dataset_npz(
        filepath: str,
        X: np.ndarray,
        y: np.ndarray,
        pairs: List[Tuple[str, str]],
        feature_names: List[str],
    ) -> None:
        """Saves feature matrix, labels, pairs, and feature names in compressed .npz format."""
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        s1_ids = np.array([p[0] for p in pairs], dtype=object)
        target_ids = np.array([p[1] for p in pairs], dtype=object)
        names = np.array(feature_names, dtype=object)

        np.savez_compressed(
            filepath,
            X=X,
            y=y,
            s1_ids=s1_ids,
            target_ids=target_ids,
            feature_names=names,
        )
        file_size_mb = os.path.getsize(filepath) / (1024 * 1024)
        logger.info(f"Saved compressed dataset ({file_size_mb:.2f} MB) to: {filepath}")

    @staticmethod
    def load_dataset_npz(
        filepath: str,
    ) -> Tuple[np.ndarray, np.ndarray, List[Tuple[str, str]], List[str]]:
        """Loads dataset from compressed .npz file."""
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Dataset file not found at: {filepath}")

        with np.load(filepath, allow_pickle=True) as data:
            X = data["X"]
            y = data["y"]
            s1_ids = data["s1_ids"]
            target_ids = data["target_ids"]
            feature_names = list(data["feature_names"])
            pairs = list(zip(s1_ids, target_ids))

        logger.info(f"Loaded dataset from {filepath}: X shape = {X.shape}, y shape = {y.shape}")
        return X, y, pairs, feature_names
