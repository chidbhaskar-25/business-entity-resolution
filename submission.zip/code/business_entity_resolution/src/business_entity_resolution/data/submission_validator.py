"""Strict competition submission validator verifying all rules and constraints."""

import argparse
import os
import sys
from typing import Any, Dict, List, Optional, Set, Tuple

DELIM = "\t"
MATCHING_HEADER = ["source1_entity_id", "matched_entity_ids"]
CANDIDATE_HEADER = ["source1_entity_id", "candidate_entity_ids"]
CORRUPT_EMPTY_STRINGS = {"none", "null", "nan", "[]", "{}", "\"\"", "''"}


class SubmissionValidationResult:
    """Detailed result of submission validation."""

    def __init__(self):
        self.is_valid: bool = True
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.stats: Dict[str, Any] = {}
        self.criteria_checks: Dict[str, bool] = {
            "correct_tsv_format": True,
            "exact_column_names": True,
            "every_s1_test_id_exists": True,
            "exactly_one_row_per_s1": True,
            "no_duplicate_s1_rows": True,
            "only_s2_s3_matches": True,
            "all_ids_exist_in_test_data": True,
            "no_duplicate_ids_in_lists": True,
            "candidate_ids_valid": True,
            "matches_subset_of_candidates": True,
            "empty_lists_correctly_represented": True,
        }

    def add_error(self, criterion: str, message: str) -> None:
        self.is_valid = False
        self.criteria_checks[criterion] = False
        self.errors.append(message)

    def add_warning(self, message: str) -> None:
        self.warnings.append(message)

    def report(self) -> str:
        """Generates a structured human-readable validation report."""
        lines = []
        lines.append("=" * 80)
        lines.append("SUBMISSION VALIDATION REPORT")
        lines.append("=" * 80)

        status_str = "PASS (100% Compliant - Safe for Leaderboard Submission)" if self.is_valid else "FAIL (Issues Detected)"
        lines.append(f"Overall Status: {status_str}\n")

        lines.append("Criteria Checklist:")
        labels = [
            ("correct_tsv_format", "1. Correct TSV format (Tab-separated, no delimiter corruption)"),
            ("exact_column_names", "2. Exact required column headers"),
            ("every_s1_test_id_exists", "3. Every Source 1 test entity present"),
            ("exactly_one_row_per_s1", "4. Exactly one row per Source 1 entity"),
            ("no_duplicate_s1_rows", "5. No duplicate Source 1 rows"),
            ("only_s2_s3_matches", "6. Only S2/S3 IDs appear as matches (Zero self-matches)"),
            ("all_ids_exist_in_test_data", "7. All entity IDs exist in test dataset"),
            ("no_duplicate_ids_in_lists", "8. No duplicate target IDs inside lists"),
            ("candidate_ids_valid", "9. Candidate IDs valid and compliant"),
            ("matches_subset_of_candidates", "10. Every final match appears in candidate_pairs.tsv"),
            ("empty_lists_correctly_represented", "11. Empty lists (singletons) correctly represented (s1_id\\t\\n)"),
        ]
        for key, desc in labels:
            mark = "[PASS]" if self.criteria_checks.get(key, False) else "[FAIL]"
            lines.append(f"  {mark} {desc}")

        lines.append("\nSummary Statistics:")
        for k, v in sorted(self.stats.items()):
            if isinstance(v, float):
                lines.append(f"  - {k}: {v:.4f}")
            elif isinstance(v, int):
                lines.append(f"  - {k}: {v:,}")
            else:
                lines.append(f"  - {k}: {v}")

        if self.errors:
            lines.append("\n" + "!" * 80)
            lines.append(f"ERRORS ({len(self.errors)} issues):")
            lines.append("!" * 80)
            for i, err in enumerate(self.errors, 1):
                lines.append(f"  {i}. {err}")

        if self.warnings:
            lines.append("\n" + "-" * 80)
            lines.append(f"WARNINGS ({len(self.warnings)} notices):")
            lines.append("-" * 80)
            for i, warn in enumerate(self.warnings, 1):
                lines.append(f"  {i}. {warn}")

        lines.append("=" * 80)
        return "\n".join(lines)


class SubmissionValidator:
    """Strict validator for Amazon ML Challenge 2026 submission files."""

    @staticmethod
    def _read_test_ids(tsv_path: str) -> Set[str]:
        """Loads first-column IDs from a source TSV."""
        ids = set()
        with open(tsv_path, "r", encoding="utf-8") as f:
            next(f, None)
            for line in f:
                line_str = line.strip()
                if line_str:
                    eid = line_str.split(DELIM, 1)[0].strip()
                    if eid:
                        ids.add(eid)
        return ids

    @classmethod
    def validate_file_format_and_schema(
        cls,
        filepath: str,
        expected_header: List[str],
        file_label: str,
        result: SubmissionValidationResult,
    ) -> Optional[List[str]]:
        """Validates that a file is a valid TSV with exact column headers."""
        if not os.path.isfile(filepath):
            result.add_error("correct_tsv_format", f"{file_label}: File not found at '{filepath}'.")
            return None

        if os.path.getsize(filepath) == 0:
            result.add_error("correct_tsv_format", f"{file_label}: File '{filepath}' is completely empty.")
            return None

        with open(filepath, "r", encoding="utf-8") as f:
            first_line = f.readline()

        if not first_line:
            result.add_error("correct_tsv_format", f"{file_label}: File contains no header row.")
            return None

        # Check for CSV comma mistake
        if DELIM not in first_line and "," in first_line:
            result.add_error(
                "correct_tsv_format",
                f"{file_label}: Header contains commas but NO tab character. "
                "Submissions must be strictly tab-separated (.tsv)."
            )
            return None

        cols = [c.strip().lower() for c in first_line.rstrip("\r\n").split(DELIM)]
        if cols != expected_header:
            result.add_error(
                "exact_column_names",
                f"{file_label}: Header columns {cols} do not match exact required {expected_header}."
            )
            return None

        return cols

    @classmethod
    def validate_submission(
        cls,
        matching_path: str,
        candidate_path: Optional[str] = None,
        test_dir: Optional[str] = None,
        expected_s1_ids: Optional[Set[str]] = None,
        check_target_ids: bool = False,
    ) -> SubmissionValidationResult:
        """Performs exhaustive validation of submission files across all 11 criteria.

        Args:
            matching_path: Path to matching_results.tsv.
            candidate_path: Path to candidate_pairs.tsv.
            test_dir: Path to directory containing test_source1.tsv (and optionally test_source2/3).
            expected_s1_ids: Explicit set of required Source 1 IDs (if sample testing).
            check_target_ids: If True, checks that every S2/S3 ID exists in test_source2/3.

        Returns:
            SubmissionValidationResult object.
        """
        result = SubmissionValidationResult()

        # 1. Load Ground Truth / Test IDs if provided
        required_s1_ids: Optional[Set[str]] = expected_s1_ids
        valid_target_ids: Optional[Set[str]] = None

        if required_s1_ids is None and test_dir and os.path.isdir(test_dir):
            s1_file = os.path.join(test_dir, "test_source1.tsv")
            if os.path.isfile(s1_file):
                required_s1_ids = cls._read_test_ids(s1_file)
                result.stats["required_s1_count"] = len(required_s1_ids)

        if check_target_ids and test_dir and os.path.isdir(test_dir):
            valid_target_ids = set()
            for tf in ["test_source2.tsv", "test_source3.tsv"]:
                t_path = os.path.join(test_dir, tf)
                if os.path.isfile(t_path):
                    valid_target_ids.update(cls._read_test_ids(t_path))
            result.stats["valid_target_ids_loaded"] = len(valid_target_ids)

        # 2. Validate Matching Results File
        matching_cols = cls.validate_file_format_and_schema(
            matching_path, MATCHING_HEADER, "matching_results.tsv", result
        )

        matched_mapping: Dict[str, List[str]] = {}
        matching_s1_seen: List[str] = []
        matching_dup_s1: Set[str] = set()
        matching_intra_dupes: Dict[str, List[str]] = {}
        matching_self_matches: Set[str] = set()
        matching_bad_prefix: Set[str] = set()
        matching_unknown_target: Set[str] = set()
        corrupt_empty_representations: List[str] = []
        matching_empty_count = 0
        matching_multi_count = 0
        matching_total_links = 0

        if matching_cols is not None:
            with open(matching_path, "r", encoding="utf-8") as f:
                next(f)  # skip header
                for line_idx, line in enumerate(f, start=2):
                    raw_line = line.rstrip("\r\n")
                    parts = raw_line.split(DELIM)

                    # TSV formatting check: exactly 2 fields
                    if len(parts) != 2:
                        result.add_error(
                            "correct_tsv_format",
                            f"matching_results.tsv: Row {line_idx} has {len(parts)} fields instead of 2. Line: {raw_line!r}"
                        )
                        continue

                    s1_id = parts[0].strip()
                    rest = parts[1].strip()

                    # S1 ID validation
                    if not s1_id:
                        result.add_error("correct_tsv_format", f"matching_results.tsv: Empty source1_entity_id at line {line_idx}.")
                        continue

                    if not s1_id.startswith("S1-"):
                        result.add_error("every_s1_test_id_exists", f"matching_results.tsv: Invalid S1 ID format '{s1_id}' at line {line_idx}.")

                    if s1_id in matched_mapping:
                        matching_dup_s1.add(s1_id)
                    matching_s1_seen.append(s1_id)

                    # Empty list check (singletons)
                    if not rest:
                        matching_empty_count += 1
                        matched_mapping[s1_id] = []
                        continue

                    # Check for corrupt string representations of empty list
                    if rest.lower() in CORRUPT_EMPTY_STRINGS:
                        corrupt_empty_representations.append(f"line {line_idx} ({s1_id}: '{rest}')")

                    # Parse comma-separated target IDs
                    tokens = [t.strip() for t in rest.split(",") if t.strip()]
                    matching_total_links += len(tokens)
                    if len(tokens) > 1:
                        matching_multi_count += 1

                    # Intra-row duplicates check
                    if len(tokens) != len(set(tokens)):
                        matching_intra_dupes[s1_id] = tokens

                    # Prefix and existence checks
                    for tid in tokens:
                        if tid.startswith("S1-"):
                            matching_self_matches.add(tid)
                        elif not (tid.startswith("S2-") or tid.startswith("S3-")):
                            matching_bad_prefix.add(tid)
                        elif valid_target_ids is not None and tid not in valid_target_ids:
                            matching_unknown_target.add(tid)

                    matched_mapping[s1_id] = tokens

            # Evaluate matching findings
            result.stats["matching_total_rows"] = len(matching_s1_seen)
            result.stats["matching_unique_s1"] = len(matched_mapping)
            result.stats["matching_singletons"] = matching_empty_count
            result.stats["matching_multi_matches"] = matching_multi_count
            result.stats["matching_total_links"] = matching_total_links

            if corrupt_empty_representations:
                result.add_error(
                    "empty_lists_correctly_represented",
                    f"matching_results.tsv: Corrupt empty string representation found at {len(corrupt_empty_representations)} rows (e.g. {corrupt_empty_representations[:3]}). "
                    "Singletons must have empty value after tab: 'S1-ID\\t\\n'."
                )

            if matching_dup_s1:
                result.add_error(
                    "no_duplicate_s1_rows",
                    f"matching_results.tsv: Found {len(matching_dup_s1)} duplicate Source 1 rows: {sorted(list(matching_dup_s1))[:5]}"
                )

            if matching_intra_dupes:
                result.add_error(
                    "no_duplicate_ids_in_lists",
                    f"matching_results.tsv: Duplicate target IDs within match list for {len(matching_intra_dupes)} entities (e.g. {list(matching_intra_dupes.keys())[:3]})."
                )

            if matching_self_matches:
                result.add_error(
                    "only_s2_s3_matches",
                    f"matching_results.tsv: Found {len(matching_self_matches)} self-matches referencing S1 IDs (e.g. {sorted(list(matching_self_matches))[:5]})."
                )

            if matching_bad_prefix:
                result.add_error(
                    "only_s2_s3_matches",
                    f"matching_results.tsv: Found {len(matching_bad_prefix)} matches without S2-/S3- prefix (e.g. {sorted(list(matching_bad_prefix))[:5]})."
                )

            if matching_unknown_target:
                result.add_error(
                    "all_ids_exist_in_test_data",
                    f"matching_results.tsv: Found {len(matching_unknown_target)} match IDs not present in test S2/S3 files (e.g. {sorted(list(matching_unknown_target))[:5]})."
                )

        # 3. Validate Candidate Pairs File (if provided)
        candidate_mapping: Dict[str, Set[str]] = {}
        if candidate_path:
            cand_cols = cls.validate_file_format_and_schema(
                candidate_path, CANDIDATE_HEADER, "candidate_pairs.tsv", result
            )
            cand_s1_seen: List[str] = []
            cand_dup_s1: Set[str] = set()
            cand_intra_dupes: Dict[str, List[str]] = {}
            cand_self_matches: Set[str] = set()
            cand_bad_prefix: Set[str] = set()
            cand_unknown_target: Set[str] = set()
            cand_corrupt_empty: List[str] = []
            cand_total_pairs = 0

            if cand_cols is not None:
                with open(candidate_path, "r", encoding="utf-8") as f:
                    next(f)
                    for line_idx, line in enumerate(f, start=2):
                        raw_line = line.rstrip("\r\n")
                        parts = raw_line.split(DELIM)
                        if len(parts) != 2:
                            result.add_error(
                                "correct_tsv_format",
                                f"candidate_pairs.tsv: Row {line_idx} has {len(parts)} fields instead of 2. Line: {raw_line!r}"
                            )
                            continue

                        s1_id = parts[0].strip()
                        rest = parts[1].strip()

                        if not s1_id:
                            result.add_error("correct_tsv_format", f"candidate_pairs.tsv: Empty source1_entity_id at line {line_idx}.")
                            continue

                        if s1_id in candidate_mapping:
                            cand_dup_s1.add(s1_id)
                        cand_s1_seen.append(s1_id)

                        if not rest:
                            candidate_mapping[s1_id] = set()
                            continue

                        if rest.lower() in CORRUPT_EMPTY_STRINGS:
                            cand_corrupt_empty.append(f"line {line_idx} ({s1_id}: '{rest}')")

                        tokens = [t.strip() for t in rest.split(",") if t.strip()]
                        cand_total_pairs += len(tokens)

                        if len(tokens) != len(set(tokens)):
                            cand_intra_dupes[s1_id] = tokens

                        for tid in tokens:
                            if tid.startswith("S1-"):
                                cand_self_matches.add(tid)
                            elif not (tid.startswith("S2-") or tid.startswith("S3-")):
                                cand_bad_prefix.add(tid)
                            elif valid_target_ids is not None and tid not in valid_target_ids:
                                cand_unknown_target.add(tid)

                        candidate_mapping[s1_id] = set(tokens)

                result.stats["candidate_total_rows"] = len(cand_s1_seen)
                result.stats["candidate_total_pairs"] = cand_total_pairs

                if cand_corrupt_empty:
                    result.add_error(
                        "empty_lists_correctly_represented",
                        f"candidate_pairs.tsv: Corrupt empty string representation found at {len(cand_corrupt_empty)} rows."
                    )

                if cand_dup_s1:
                    result.add_error(
                        "no_duplicate_s1_rows",
                        f"candidate_pairs.tsv: Found {len(cand_dup_s1)} duplicate Source 1 rows."
                    )

                if cand_intra_dupes:
                    result.add_error(
                        "no_duplicate_ids_in_lists",
                        f"candidate_pairs.tsv: Duplicate candidate IDs within list for {len(cand_intra_dupes)} entities."
                    )

                if cand_self_matches:
                    result.add_error(
                        "candidate_ids_valid",
                        f"candidate_pairs.tsv: Found {len(cand_self_matches)} S1 self-matches in candidates."
                    )

                if cand_bad_prefix:
                    result.add_error(
                        "candidate_ids_valid",
                        f"candidate_pairs.tsv: Found {len(cand_bad_prefix)} candidate IDs without S2-/S3- prefix."
                    )

                if cand_unknown_target:
                    result.add_error(
                        "all_ids_exist_in_test_data",
                        f"candidate_pairs.tsv: Found {len(cand_unknown_target)} candidate IDs not present in test S2/S3 files."
                    )

        # 4. Cross-file checks: Required Source 1 Entities
        if required_s1_ids is not None:
            seen_in_match = set(matched_mapping.keys())
            missing_in_match = required_s1_ids - seen_in_match
            if missing_in_match:
                result.add_error(
                    "every_s1_test_id_exists",
                    f"matching_results.tsv: Missing {len(missing_in_match):,} required Source 1 entities (e.g. {sorted(list(missing_in_match))[:5]})."
                )

            extra_in_match = seen_in_match - required_s1_ids
            if extra_in_match:
                result.add_error(
                    "all_ids_exist_in_test_data",
                    f"matching_results.tsv: Found {len(extra_in_match)} entities not in required Source 1 set (e.g. {sorted(list(extra_in_match))[:5]})."
                )

            if len(matching_s1_seen) != len(required_s1_ids):
                result.add_error(
                    "exactly_one_row_per_s1",
                    f"matching_results.tsv: Expected exactly {len(required_s1_ids):,} rows, but found {len(matching_s1_seen):,} rows."
                )

            if candidate_path and candidate_mapping:
                seen_in_cand = set(candidate_mapping.keys())
                missing_in_cand = required_s1_ids - seen_in_cand
                if missing_in_cand:
                    result.add_error(
                        "every_s1_test_id_exists",
                        f"candidate_pairs.tsv: Missing {len(missing_in_cand):,} required Source 1 entities."
                    )
                if len(candidate_mapping) != len(required_s1_ids):
                    result.add_error(
                        "exactly_one_row_per_s1",
                        f"candidate_pairs.tsv: Expected exactly {len(required_s1_ids):,} rows, but found {len(candidate_mapping):,} rows."
                    )

        # 5. Constraint: Every match must appear in candidate_pairs.tsv
        if candidate_path and candidate_mapping:
            subset_violations: Dict[str, List[str]] = {}
            for s1_id, matches in matched_mapping.items():
                cands = candidate_mapping.get(s1_id, set())
                invalid_matches = [m for m in matches if m not in cands]
                if invalid_matches:
                    subset_violations[s1_id] = invalid_matches

            if subset_violations:
                result.add_error(
                    "matches_subset_of_candidates",
                    f"Found {len(subset_violations)} entities where matches are NOT in candidates! "
                    f"Examples: {list(subset_violations.items())[:3]}"
                )

        return result


def main():
    parser = argparse.ArgumentParser(description="Strict submission validator for Amazon ML Challenge 2026")
    parser.add_argument("--matching", type=str, default="outputs/matching_results.tsv", help="Matching TSV path")
    parser.add_argument("--candidate", type=str, default="outputs/candidate_pairs.tsv", help="Candidate TSV path")
    parser.add_argument("--test-dir", type=str, default="data/test", help="Test data directory")
    parser.add_argument("--check-target-ids", action="store_true", help="Check that all S2/S3 IDs exist in test_source2/3")
    parser.add_argument("--s1-sample-size", type=int, default=None, help="If validating a sample run, specify S1 entity count")
    args = parser.parse_args()

    expected_s1 = None
    if args.s1_sample_size is not None and args.test_dir:
        # Load only first N IDs from test_source1.tsv
        s1_file = os.path.join(args.test_dir, "test_source1.tsv")
        if os.path.isfile(s1_file):
            expected_s1 = set()
            with open(s1_file, "r", encoding="utf-8") as f:
                next(f)
                for _ in range(args.s1_sample_size):
                    line = f.readline()
                    if not line:
                        break
                    expected_s1.add(line.split(DELIM, 1)[0].strip())

    validator = SubmissionValidator()
    result = validator.validate_submission(
        matching_path=args.matching,
        candidate_path=args.candidate,
        test_dir=args.test_dir,
        expected_s1_ids=expected_s1,
        check_target_ids=args.check_target_ids,
    )

    print(result.report())
    sys.exit(0 if result.is_valid else 1)


if __name__ == "__main__":
    main()
