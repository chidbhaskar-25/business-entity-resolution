"""Validation utilities for input datasets and competition output submissions."""

import os
from typing import Dict, List, Optional, Set, Tuple
import pandas as pd
from pydantic import BaseModel

from ..utils.logger import setup_logger

logger = setup_logger("data.validator")

REQUIRED_SOURCE_COLUMNS = ["entity_id", "business_name", "business_address", "country"]
REQUIRED_GROUND_TRUTH_COLUMNS = ["source1_entity_id", "matched_entity_ids"]
MATCHING_HEADER = ["source1_entity_id", "matched_entity_ids"]
CANDIDATE_HEADER = ["source1_entity_id", "candidate_entity_ids"]
DELIM = "\t"


class ValidationReport(BaseModel):
    """Structured report detailing validation findings."""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    stats: Dict[str, int]


class DataValidator:
    """Validates raw source datasets and ground truth labels."""

    @staticmethod
    def validate_source_dataframe(
        df: pd.DataFrame,
        expected_prefix: str,
        file_label: str = "source",
    ) -> Tuple[bool, List[str], List[str]]:
        """Checks schema, ID prefixes, duplicates, and missing values for a source dataframe.

        Treats country as an OPEN SET: country labels can be any valid string (US, India, France, etc.).

        Args:
            df: DataFrame to validate.
            expected_prefix: Expected ID prefix ('S1-', 'S2-', or 'S3-').
            file_label: Descriptive label for reporting.

        Returns:
            Tuple of (is_valid: bool, errors: List[str], warnings: List[str]).
        """
        errors: List[str] = []
        warnings: List[str] = []

        # 1. Column Validation
        actual_cols = list(df.columns)
        missing_cols = [c for c in REQUIRED_SOURCE_COLUMNS if c not in actual_cols]
        if missing_cols:
            errors.append(f"{file_label}: Missing required columns: {missing_cols}")

        extra_cols = [c for c in actual_cols if c not in REQUIRED_SOURCE_COLUMNS and not c.startswith("raw_")]
        if extra_cols:
            warnings.append(f"{file_label}: Detected unexpected columns: {extra_cols}")

        if "entity_id" in df.columns:
            # 2. Entity ID Missing Checks
            null_ids = df["entity_id"].isna() | (df["entity_id"].astype(str).str.strip() == "")
            if null_ids.any():
                errors.append(f"{file_label}: Found {null_ids.sum()} records with missing/empty entity_id.")

            # 3. Entity ID Prefix Validation
            id_series = df["entity_id"].astype(str).str.strip()
            invalid_prefix_mask = ~id_series.str.startswith(expected_prefix)
            if invalid_prefix_mask.any():
                bad_samples = id_series[invalid_prefix_mask].head(5).tolist()
                errors.append(
                    f"{file_label}: Found {invalid_prefix_mask.sum()} IDs without required prefix '{expected_prefix}'. "
                    f"Sample: {bad_samples}"
                )

            # 4. Duplicate Entity ID Detection
            duplicate_mask = df["entity_id"].duplicated()
            if duplicate_mask.any():
                dup_samples = df.loc[duplicate_mask, "entity_id"].head(5).tolist()
                errors.append(
                    f"{file_label}: Found {duplicate_mask.sum()} duplicate entity IDs. Sample: {dup_samples}"
                )

        # 5. Missing Values Checks
        if "business_name" in df.columns:
            empty_names = df["business_name"].isna() | (df["business_name"].astype(str).str.strip() == "")
            if empty_names.any():
                warnings.append(f"{file_label}: Found {empty_names.sum()} records with empty business_name.")

        if "business_address" in df.columns:
            empty_addrs = df["business_address"].isna() | (df["business_address"].astype(str).str.strip() == "")
            if empty_addrs.any():
                warnings.append(
                    f"{file_label}: Found {empty_addrs.sum()} ({empty_addrs.mean():.2%}) records with empty business_address. "
                    "Empty addresses are expected in noisy sources S2/S3."
                )

        # 6. Open-Set Country Validation
        if "country" in df.columns:
            empty_country = df["country"].isna() | (df["country"].astype(str).str.strip() == "")
            if empty_country.any():
                errors.append(f"{file_label}: Found {empty_country.sum()} records with missing country label.")
            else:
                observed_countries = sorted(df["country"].dropna().unique().tolist())
                logger.debug(f"{file_label}: Open-set country values verified: {observed_countries}")

        is_valid = len(errors) == 0
        return is_valid, errors, warnings

    @staticmethod
    def validate_ground_truth_dataframe(
        df: pd.DataFrame,
        file_label: str = "ground_truth",
    ) -> Tuple[bool, List[str], List[str]]:
        """Validates ground truth dataframe schema, prefixes, and link constraints."""
        errors: List[str] = []
        warnings: List[str] = []

        actual_cols = list(df.columns)
        missing_cols = [c for c in REQUIRED_GROUND_TRUTH_COLUMNS if c not in actual_cols]
        if missing_cols:
            errors.append(f"{file_label}: Missing required columns: {missing_cols}")
            return False, errors, warnings

        s1_series = df["source1_entity_id"].astype(str).str.strip()
        # S1 prefix check
        bad_s1 = ~s1_series.str.startswith("S1-")
        if bad_s1.any():
            errors.append(
                f"{file_label}: Found {bad_s1.sum()} source1_entity_id values without 'S1-' prefix."
            )

        # Duplicate S1 rows check
        dup_s1 = s1_series.duplicated()
        if dup_s1.any():
            errors.append(
                f"{file_label}: Found {dup_s1.sum()} duplicate source1_entity_id rows."
            )

        # Validate matched targets
        self_matches = 0
        intra_dupes = 0
        invalid_prefix_matches = 0

        for s1_id, raw_matches in zip(s1_series, df["matched_entity_ids"]):
            if pd.isna(raw_matches) or not str(raw_matches).strip():
                continue
            targets = [m.strip() for m in str(raw_matches).split(",") if m.strip()]
            if len(targets) != len(set(targets)):
                intra_dupes += 1

            for t in targets:
                if t.startswith("S1-"):
                    self_matches += 1
                elif not (t.startswith("S2-") or t.startswith("S3-")):
                    invalid_prefix_matches += 1

        if self_matches > 0:
            errors.append(f"{file_label}: Found {self_matches} self-matches referencing S1 IDs.")
        if invalid_prefix_matches > 0:
            errors.append(
                f"{file_label}: Found {invalid_prefix_matches} matches not starting with S2- or S3-."
            )
        if intra_dupes > 0:
            errors.append(
                f"{file_label}: Found {intra_dupes} rows with duplicate targets within matched_entity_ids."
            )

        is_valid = len(errors) == 0
        return is_valid, errors, warnings


class OutputValidator:
    """Validates output submissions against official challenge criteria."""

    @staticmethod
    def validate_id_list_file(
        filepath: str,
        expected_header: List[str],
        col_label: str,
        required_s1_ids: Optional[Set[str]] = None,
        valid_target_ids: Optional[Set[str]] = None,
    ) -> Tuple[Optional[Dict[str, Set[str]]], List[str], Dict[str, int]]:
        """Parses and validates a tab-separated results file."""
        errors: List[str] = []
        stats = {"total_rows": 0, "empty_rows": 0, "non_empty_rows": 0, "total_links": 0}

        if not os.path.isfile(filepath):
            errors.append(f"File not found: {filepath}")
            return None, errors, stats

        name = os.path.basename(filepath)
        mapping: Dict[str, Set[str]] = {}
        seen_s1: Set[str] = set()
        dup_rows: Set[str] = set()
        intra_dupes: Set[str] = set()
        self_matches: Set[str] = set()
        wrong_prefix: Set[str] = set()
        unknown_targets: Set[str] = set()

        with open(filepath, "r", encoding="utf-8") as f:
            header_line = f.readline()
            if not header_line:
                errors.append(f"{name}: File is empty.")
                return None, errors, stats

            if DELIM not in header_line and "," in header_line:
                errors.append(
                    f"{name}: Header has no TAB but contains commas. "
                    "File must be TAB-separated (.tsv)."
                )
                return None, errors, stats

            cols = [c.strip().lower() for c in header_line.rstrip("\r\n").split(DELIM)]
            if cols != expected_header:
                errors.append(
                    f"{name}: Unexpected header {cols}. Expected exactly {expected_header} (tab-separated)."
                )
                return None, errors, stats

            for line_idx, line in enumerate(f, start=2):
                parts = line.rstrip("\r\n").split(DELIM)
                if len(parts) < 2:
                    if line.strip():
                        errors.append(f"{name}: Malformed row at line {line_idx}: {line.strip()!r}")
                    continue

                s1_id = parts[0].strip()
                rest = parts[1].strip()
                stats["total_rows"] += 1

                if s1_id in seen_s1:
                    dup_rows.add(s1_id)
                seen_s1.add(s1_id)

                if not rest:
                    stats["empty_rows"] += 1
                    mapping[s1_id] = set()
                    continue

                stats["non_empty_rows"] += 1
                id_tokens = [m.strip() for m in rest.split(",") if m.strip()]
                stats["total_links"] += len(id_tokens)

                if len(id_tokens) != len(set(id_tokens)):
                    intra_dupes.add(s1_id)

                id_set = set(id_tokens)
                mapping[s1_id] = id_set

                for mid in id_set:
                    if mid.startswith("S1-"):
                        self_matches.add(mid)
                    elif not mid.startswith(("S2-", "S3-")):
                        wrong_prefix.add(mid)
                    elif valid_target_ids is not None and mid not in valid_target_ids:
                        unknown_targets.add(mid)

        if dup_rows:
            errors.append(f"{name}: Duplicate source1_entity_id row(s): {len(dup_rows)} found.")
        if intra_dupes:
            errors.append(f"{name}: Repeated ID inside {col_label} for: {len(intra_dupes)} entities.")
        if self_matches:
            errors.append(f"{name}: Contains Source-1 IDs (self-matches): {len(self_matches)} found.")
        if wrong_prefix:
            errors.append(f"{name}: Contains IDs without S2-/S3- prefix: {len(wrong_prefix)} found.")
        if unknown_targets:
            errors.append(f"{name}: References {len(unknown_targets)} IDs not in valid target set.")

        if required_s1_ids is not None:
            missing_required = required_s1_ids - seen_s1
            if missing_required:
                errors.append(
                    f"{name}: {len(missing_required)} required Source 1 entities missing. "
                    f"Sample: {list(missing_required)[:5]}"
                )
            extra_s1 = seen_s1 - required_s1_ids
            if extra_s1:
                errors.append(
                    f"{name}: {len(extra_s1)} S1 entities found that are not in test set."
                )

        return mapping, errors, stats

    @classmethod
    def validate_submission(
        cls,
        matching_path: str,
        candidate_path: Optional[str] = None,
        test_dir: Optional[str] = None,
        check_target_ids: bool = False,
        required_s1_ids: Optional[Set[str]] = None,
    ) -> ValidationReport:
        """Runs full validation suite on matching and candidate output files."""
        all_errors: List[str] = []
        all_warnings: List[str] = []
        combined_stats: Dict[str, int] = {}

        valid_target_ids: Optional[Set[str]] = None

        if required_s1_ids is None and test_dir and os.path.exists(test_dir):
            s1_path = os.path.join(test_dir, "test_source1.tsv")
            if os.path.isfile(s1_path):
                with open(s1_path, "r", encoding="utf-8") as f:
                    next(f, None)
                    required_s1_ids = {line.split(DELIM, 1)[0].strip() for line in f if line.strip()}
                logger.info(f"Loaded {len(required_s1_ids):,} required S1 test IDs for validation.")

            if check_target_ids:
                targets = set()
                for target_file in ["test_source2.tsv", "test_source3.tsv"]:
                    target_path = os.path.join(test_dir, target_file)
                    if os.path.isfile(target_path):
                        with open(target_path, "r", encoding="utf-8") as f:
                            next(f, None)
                            targets.update({line.split(DELIM, 1)[0].strip() for line in f if line.strip()})
                valid_target_ids = targets
                logger.info(f"Loaded {len(valid_target_ids):,} valid target S2/S3 IDs for validation.")

        matched_map, match_errors, match_stats = cls.validate_id_list_file(
            filepath=matching_path,
            expected_header=MATCHING_HEADER,
            col_label="matched_entity_ids",
            required_s1_ids=required_s1_ids,
            valid_target_ids=valid_target_ids,
        )
        all_errors.extend(match_errors)
        for k, v in match_stats.items():
            combined_stats[f"matching_{k}"] = v

        candidate_map = None
        if candidate_path and os.path.isfile(candidate_path):
            candidate_map, cand_errors, cand_stats = cls.validate_id_list_file(
                filepath=candidate_path,
                expected_header=CANDIDATE_HEADER,
                col_label="candidate_entity_ids",
                required_s1_ids=required_s1_ids,
                valid_target_ids=valid_target_ids,
            )
            all_errors.extend(cand_errors)
            for k, v in cand_stats.items():
                combined_stats[f"candidate_{k}"] = v
        elif candidate_path:
            all_warnings.append(f"Candidate file not found: {candidate_path}")

        # Check: Final matches must be a subset of candidate pairs
        if matched_map is not None and candidate_map is not None:
            offending_s1 = []
            for s1_id, matches in matched_map.items():
                candidates = candidate_map.get(s1_id, set())
                unblocked_matches = matches - candidates
                if unblocked_matches:
                    offending_s1.append((s1_id, len(unblocked_matches)))

            if offending_s1:
                all_warnings.append(
                    f"{len(offending_s1)} Source 1 entities have matches not present in candidate_pairs.tsv. "
                    f"Sample: {offending_s1[:3]}"
                )

        is_valid = len(all_errors) == 0
        return ValidationReport(
            is_valid=is_valid,
            errors=all_errors,
            warnings=all_warnings,
            stats=combined_stats,
        )
