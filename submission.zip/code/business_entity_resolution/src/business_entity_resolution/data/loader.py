"""Data loader for Amazon ML Challenge 2026 Business Entity Resolution."""

import os
from typing import Dict, Iterator, List, Optional, Set, Tuple
import pandas as pd

from .validator import DataValidator
from ..utils.logger import setup_logger

logger = setup_logger("data.loader")

REQUIRED_COLUMNS = ["entity_id", "business_name", "business_address", "country"]
GROUND_TRUTH_COLUMNS = ["source1_entity_id", "matched_entity_ids"]


class DataLoader:
    """Manages reading, streaming, and safe handling of entity resolution datasets."""

    def __init__(self, data_dir: str):
        """Initializes DataLoader with a base directory.

        Args:
            data_dir: Path to directory containing the tsv files.
        """
        self.data_dir = data_dir

    def get_path(self, filename: str) -> str:
        """Returns the full path for a given filename."""
        return os.path.join(self.data_dir, filename)

    def load_source_df(
        self,
        filename: str,
        nrows: Optional[int] = None,
        usecols: Optional[List[str]] = None,
        validate: bool = False,
        expected_prefix: Optional[str] = None,
        preserve_raw: bool = True,
    ) -> pd.DataFrame:
        """Loads a source TSV file using sep='\\t' into a pandas DataFrame.

        Safely handles missing values, preserves raw input columns, and validates schema.

        Args:
            filename: Name of the TSV file (e.g. 'train_source1.tsv').
            nrows: Optional maximum number of rows to read.
            usecols: Optional subset of columns to load.
            validate: Whether to run DataValidator on the loaded dataframe.
            expected_prefix: Optional entity ID prefix (e.g. 'S1-', 'S2-', 'S3-').
            preserve_raw: If True, preserves raw business_name and business_address in raw_* columns.

        Returns:
            Cleaned pandas DataFrame with preserved raw data.
        """
        path = self.get_path(filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Source file not found at: {path}")

        logger.info(f"Loading {filename} with sep='\\t' (nrows={nrows})...")
        cols = usecols or REQUIRED_COLUMNS

        # Read TSV with explicit tab separator
        df = pd.read_csv(
            path,
            sep="\t",
            nrows=nrows,
            usecols=cols,
            dtype=str,
            keep_default_na=False,
            na_values=[""],
        )

        # Preserve original raw strings before any modifications
        if preserve_raw:
            if "business_name" in df.columns:
                df["raw_business_name"] = df["business_name"].fillna("").astype(str)
            if "business_address" in df.columns:
                df["raw_business_address"] = df["business_address"].fillna("").astype(str)
            if "country" in df.columns:
                df["raw_country"] = df["country"].fillna("").astype(str)

        # Standardize missing values to empty string without altering semantics
        for col in ["business_name", "business_address", "country"]:
            if col in df.columns:
                df[col] = df[col].fillna("").astype(str)

        # Optional validation
        if validate and expected_prefix:
            is_valid, errors, warnings = DataValidator.validate_source_dataframe(
                df=df,
                expected_prefix=expected_prefix,
                file_label=filename,
            )
            for w in warnings:
                logger.warning(f"[{filename}] {w}")
            if not is_valid:
                error_msg = f"Validation failed for {filename}: {'; '.join(errors)}"
                logger.error(error_msg)
                raise ValueError(error_msg)

        logger.info(f"Loaded {len(df):,} records from {filename}")
        return df

    def stream_source_chunks(
        self,
        filename: str,
        chunk_size: int = 10000,
        max_rows: Optional[int] = None,
        preserve_raw: bool = True,
    ) -> Iterator[pd.DataFrame]:
        """Streams a source TSV file in chunks with sep='\\t' to conserve memory.

        Args:
            filename: Name of TSV file.
            chunk_size: Number of rows per chunk.
            max_rows: Optional cap on total rows read across chunks.
            preserve_raw: If True, preserves raw columns.

        Yields:
            DataFrames of chunk_size rows.
        """
        path = self.get_path(filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Source file not found at: {path}")

        total_read = 0
        reader = pd.read_csv(
            path,
            sep="\t",
            chunksize=chunk_size,
            dtype=str,
            keep_default_na=False,
            na_values=[""],
        )

        for chunk in reader:
            if preserve_raw:
                if "business_name" in chunk.columns:
                    chunk["raw_business_name"] = chunk["business_name"].fillna("").astype(str)
                if "business_address" in chunk.columns:
                    chunk["raw_business_address"] = chunk["business_address"].fillna("").astype(str)
                if "country" in chunk.columns:
                    chunk["raw_country"] = chunk["country"].fillna("").astype(str)

            for col in ["business_name", "business_address", "country"]:
                if col in chunk.columns:
                    chunk[col] = chunk[col].fillna("").astype(str)

            if max_rows is not None and total_read + len(chunk) > max_rows:
                remaining = max_rows - total_read
                yield chunk.iloc[:remaining]
                break

            total_read += len(chunk)
            yield chunk

    def load_ground_truth(
        self,
        filename: str = "train_ground_truth.tsv",
        nrows: Optional[int] = None,
        validate: bool = False,
    ) -> Dict[str, Set[str]]:
        """Loads ground truth matching labels into a mapping {s1_id: set(matched_ids)}.

        Args:
            filename: Name of ground truth file.
            nrows: Optional maximum rows to load.
            validate: Whether to validate ground truth integrity.

        Returns:
            Dictionary mapping Source 1 entity ID to set of matching S2/S3 entity IDs.
        """
        path = self.get_path(filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Ground truth file not found at: {path}")

        logger.info(f"Loading ground truth from {filename} with sep='\\t' (nrows={nrows})...")
        df = pd.read_csv(
            path,
            sep="\t",
            nrows=nrows,
            dtype=str,
            keep_default_na=False,
            na_values=[""],
        )

        if validate:
            is_valid, errors, warnings = DataValidator.validate_ground_truth_dataframe(df, filename)
            for w in warnings:
                logger.warning(f"[{filename}] {w}")
            if not is_valid:
                error_msg = f"Ground truth validation failed: {'; '.join(errors)}"
                logger.error(error_msg)
                raise ValueError(error_msg)

        mapping: Dict[str, Set[str]] = {}
        for _, row in df.iterrows():
            s1_id = str(row["source1_entity_id"]).strip()
            raw_matches = row.get("matched_entity_ids")
            if pd.isna(raw_matches) or not str(raw_matches).strip():
                mapping[s1_id] = set()
            else:
                matches = {m.strip() for m in str(raw_matches).split(",") if m.strip()}
                mapping[s1_id] = matches

        logger.info(f"Loaded ground truth for {len(mapping):,} Source 1 entities")
        return mapping
