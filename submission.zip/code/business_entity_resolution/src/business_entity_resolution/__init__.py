"""Business Entity Resolution Package for Amazon ML Challenge 2026."""

__version__ = "1.0.0"
